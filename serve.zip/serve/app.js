//gwc/app.js
//功能：服务器端程序
//1:下载四个模块
//  express			web服务器
//  mysql				mysql驱动
//  cors				处理跨域
//  express-session	会话session对象
//2:vue_server_000/进入命令行
//  npm i mysql express express-session cors
//3:加载四个第三方模块
const express=require("express");
const mysql = require("mysql");
const cors = require("cors");
const session = require("express-session");

//4:配置数据库连接池:基本效率高保证
var pool = mysql.createPool({
   host:"0.0.0.0",
   user:"root",
   password:"",
   database:"gwc",
   port:3306,
   connectionLimit:20
})
//5:创建web服务器
var server = express();
//6:配置跨域  允许程序列表
//  http://127.0.0.1:8080
//  http://localhost:8080
// server.use(cors({
//     origin:["http://192.168.1.136:8080","http://localhost:8080"],
//     credentials:true,  //每次请求验证s
//  }))
server.use((req, res, next) => {
    //判断路径
      if(req.path !== '/' && !req.path.includes('.')){   
        res.set({
          'Access-Control-Allow-Credentials': true, //允许后端发送cookie
          'Access-Control-Allow-Origin': req.headers.origin || '*' , //任意域名都可以访问,或者基于我请求头里面的域
          'Access-Control-Allow-Headers': 'X-Requested-With,Content-Type', //设置请求头格式和类型
          'Access-Control-Allow-Methods': 'PUT,POST,GET,DELETE,OPTIONS',//允许支持的请求方式
          'Content-Type': 'application/json; charset=utf-8'//默认与允许的文本格式json和编码格式
        })
      }
      req.method === 'OPTIONS' ? res.status(204).end() : next()
    })

//7:配置session环境
server.use(session({
    secret:"128位安全字符串",
    resave:true,         //请求更新数据 
    saveUninitialized:true//保存初始数据
 }));
//设置跨域访问
//8:配置静态目录 pubic
//8.1:创建public
server.use(express.static("public"))
//9:启动监听端口  3000
server.listen(3000);

//功能一：用户注册
// 1.查询是否已经被注册
server.get('/api/select_user',(req,res)=>{
    // 1.获取参数
    var uname=req.query.uname;
    // 2.执行sql语句
    pool.query("select id from gwc_login where uname = ?",[uname],(err,result)=>{
        //出现错，程序停
        if(err)throw err;
        if(result.length==0){
            res.send({code:-1,msg:"用户不存在"});
        }else{
            res.send({code:1,msg:"用户已存在"});
        }
    })
})
// 2.注册用户密码
server.get('/api/register',(req,res)=>{
    // 1.获取参数
    var uname=req.query.uname;
    var upwd=req.query.upwd;
    // 2.执行sql语句
    pool.query("INSERT INTO gwc_login VALUES(null,?,md5(?))",[uname,upwd],(err,result)=>{
        //出现错，程序停止
        if(err)throw err;
        console.log("log"+result)
        if(result.length==0){
            res.send({code:-1,msg:"注册失败"});
        }else{
            res.send({code:1,msg:"注册成功"});
        }
    })
})
//功能二：用户登录
server.get('/api/login',(req,res)=>{
    //1.获取参数uname/upwd
    //脚手架传数 
    // http://127.0.0.1:3000?uname=tom&upwd=123 
    var uname=req.query.uname;
    var upwd=req.query.upwd;
    console.log(1+":"+uname+":"+upwd);
    //2.执行sql语句
    pool.query("select id from gwc_login where uname = ? and upwd = md5(?)",[uname,upwd],(err,result)=>{
        //出现错误，程序停止
        if(err)throw err;
        if(result.length==0){
            res.send({code:-1,msg:"用户名或密码错误"});
        }else{
            //获取当前用户的id，uname
            var uid=result[0].id;
            //将用户id和uname保存session对象
            req.session.uid=uid;
            console.log("保存session是："+req.session)
            console.log("保存到session的id："+req.session.uid)
            res.send({code:1,msg:"登录成功",session:uid});
        }
    })
})

// 功能三：查找密码
server.get("/api/changePwd",(req,res)=>{
    // 1.获取参数uname
    var uname=req.query.uname;
    var upwd=req.query.upwd;
    console.log(uname+":"+upwd)
    pool.query("UPDATE gwc_login SET upwd=md5(?) WHERE uname=?",[upwd,uname],(err,result)=>{
        //错误直接终止程序
        if(err)throw err;
        //查询返回的数据
        //console.log(result)
        // 4.判断是否成功
        if(result.length==0){
            res.send({code:-1,msg:"用户名不存在"})
        }else{
            res.send({code:1,msg:"修改成功"})
        }
    })
})

//功能四：商品列表
server.get("/api/product",(req,res)=>{
    //1.获取参数
    var pno=req.query.pno;
    var ps=req.query.pageSize;
    //2.设置数据默认值  (没有接受到数据的话执行)
    if(!pno){pno=1}
    if(!ps){ps=20} 
    //计算offset数据库第一参数
    var offset=(pno-1)*ps;
     //5:给pageSize造型整型
    ps = parseInt(ps);
    // 发送sql1语句
    pool.query("SELECT lid,price,title,pic FROM gwc_product LIMIT ?,?",[offset,ps],(err,result)=>{
        //产生错误
        if(err)throw err;
        //查询结果
        var data = result;
        // 查询总记录数计算总页数  （总页数=总记录数/每页记录数）
        pool.query('select count(lid) as c from gwc_product',(err,result)=>{
            //产生错误
            if(err)throw err;
            var pageCount=Math.ceil(result[0].c/ps);
            res.send({
                code:1,msg:"查询成功",
                rows:data,
                pageCount:pageCount
            })
        })
    })
})

// 功能五：添加购物车
server.get("/api/addcart",(req,res)=>{
    // 获取当前登录用户uid
    var uid=req.session.uid;
    console.log("调用session是："+req.session)
    console.log("调用session中的id："+req.session.uid)
    //如果用户没有登录
    if(!uid){
        //返回错误消息，请登录
        res.send({code:-1,msg:"请登录",session:req.session});
        return;
    }
    //获取商品编号，商品价格，商品名称
    var lid=req.query.lid;
    var pic=req.query.pic;
    var title=req.query.title;
    var price=req.query.price;
    console.log(lid,pic,title,price)
    //查询指定用户是否购买过此商品
    pool.query("SELECT id FROM gwc_cart WHERE uid = ? AND lid = ?",[uid,lid],(err,result)=>{
        // 错误提示
        if(err)throw err;
        // 如果用户没有购买过就添加商品
        if(result.length==0){
            var sql=`INSERT INTO gwc_cart VALUES(null,${uid},${lid},'${pic}','${title}','${price}',1)`
        }else{
            var sql =`UPDATE gwc_cart SET count=count+1 WHERE uid=${uid} AND lid=${lid}`;
        }
        pool.query(sql,(err,result)=>{
            if(err)throw err;
            res.send({code:1,msg:"添加成功"})
        })
    })
})

//商品搜索--搜索按钮
server.get("/api/Search",(req,res)=>{
        //1.获取参数
        var pno=req.query.pno;
        var ps=req.query.pageSize;
        //2.设置数据默认值  (没有接受到数据的话执行)
        if(!pno){pno=1}
        if(!ps){ps=20} 
        //5:给pageSize造型整型
        ps = parseInt(ps);
        var key=req.query.key;
        pool.query(`select count(lid) as c from gwc_product WHERE title like "%${key}%"`,(err,result)=>{
            //产生错误
            if(err)throw err;
            if(result.length==0){
                res.send({code:-1,msg:"查询失败"})
            }else{
                var pageCount=Math.ceil(result[0].c/ps);
                if(pno>pageCount){pno=1}
                //计算offset数据库第一参数
                var offset=(pno-1)*ps;
                pool.query(`SELECT lid,pic,price,title FROM gwc_product WHERE title like "%${key}%" LIMIT ?,?`,[offset,ps],(err,result)=>{
                    if(err) throw err;
                    res.send({
                        code:1,msg:"查询成功",
                        rows:result,
                        pageCount:pageCount,
                        pno:pno
                    })
                })     
            }     
        })
    })

//单个商品搜索
server.get("/api/Search_label",(req,res)=>{
    var lid=req.query.lid;
    pool.query(`SELECT lid,pic,price,title FROM gwc_product WHERE lid=?`,[lid],(err,result)=>{
        if(err) throw err;
        if(result.length==0){
            res.send({code:-1,msg:"查询失败"})
        }else{
            res.send({code:1,msg:"查询成功",rows:result})
        }
    })
})

//用户名显示
server.get("/api/showUname",(req,res)=>{
    var uid=req.session.uid;
    if(!uid){
        res.send({code:-1,msg:"请登录",uname:"亲，请登录"});
        return;
    }
    pool.query('select uname from gwc_login where id=?',[uid],(err,result)=>{
        if(err) throw err;
        var uname=result[0].uname;
        if(result.length==0){
            res.send({code:-1,msg:"用户名未找到"})
        }else{
            res.send({code:1,msg:"用户名查询成功",uname:uname})
        }
    })
})


//清空session
server.get("/api/out",(req,res)=>{
    req.session.uid = null;  //清空数据
    console.log("清空session="+!req.session.uid)
    if(!req.session.uid){
        res.send({code:1,msg:"已清空session"})
    }else{
        res.send({code:-1,msg:"清空失败"})
    }
})

//按价格搜索商品
server.get("/api/Search_money",(req,res)=>{
    //1.获取参数
    var min=req.query.min_money;
    var max=req.query.max_money;
    var pno=req.query.pno;
    var ps=req.query.pageSize;
    //2.设置数据默认值  (没有接受到数据的话执行)
    if(!pno){pno=1}
    if(!ps){ps=20} 
    //5:给pageSize造型整型
    ps = parseInt(ps);
     // 查询总记录数计算总页数  （总页数=总记录数/每页记录数）
    pool.query('select count(lid) as c from gwc_product where price>=? and price<=?',[min,max],(err,result)=>{
        //产生错误
        if(err)throw err;
        var pageCount=Math.ceil(result[0].c/ps);
        if(pno>pageCount){pno=1}
        //计算offset数据库第一参数
         var offset=(pno-1)*ps;
        if(result.length==0){
            res.send({code:-1,msg:"查询失败"})
        }else{
            pool.query('select lid,pic,title,price from gwc_product where price>=? and price<=? LIMIT ?,?',[min,max,offset,ps],(err,result)=>{
                if(err)throw err;
                res.send({
                    code:1,msg:"查询成功",
                    rows:result,
                    pageCount:pageCount,
                    pno:pno
                })
            })
        }     
    })  
})

//  搜索用户的购物车商品-列表
server.get("/api/Search_cart",(req,res)=>{
    var uid=req.session.uid;
    if(!uid){
        res.send({code:-1,msg:"请登录",uname:"亲，请登录"});
        return;
    }else{
        pool.query('select id,uid,lid,pic,title,price,count from gwc_cart where uid=?',[uid],(err,result)=>{
            if(err)throw err;
            if(result.length==0){
                res.send({code:-2,msg:"未找到！"});
            }else{
                res.send({code:1,msg:"查找成功",rows:result})
            }
        })
    }
})

//修改gwc_cart表中count的数
//加按钮
server.get('/api/add_count',(req,res)=>{
    var id=req.query.id;
    pool.query('UPDATE gwc_cart SET count=count+1 WHERE id=?',[id],(err,result)=>{
        if(err)throw err;
        res.send({code:1,msg:"count修改成功"})
    })
})
//减按钮
server.get('/api/cut_count',(req,res)=>{
    var id=req.query.id;
    pool.query('UPDATE gwc_cart SET count=count-1 WHERE id=?',[id],(err,result)=>{
        if(err)throw err;
        res.send({code:1,msg:"count修改成功"})
    })
})

//删除对应列表
server.get('/api/del',(req,res)=>{
    var id=req.query.id;
    pool.query('DELETE FROM gwc_cart WHERE id = ?',[id],(err,result)=>{
        if(err)throw err;
        if(result.affectedRows>0){
            res.send({code:1,msg:"删除成功"})
        }else{
            res.send({code:-1,msg:"删除失败"})
          }
    })
})

//删除选择的商品
server.get('/api/select_del',(req,res)=>{
    var ids=req.query.ids;
    pool.query(`DELETE FROM gwc_cart WHERE id in (${ids})`,(err,result)=>{
        if(err)throw err;
        if(result.affectedRows>0){
            res.send({code:1,msg:"删除成功"})
        }else{
            res.send({code:-1,msg:"删除失败"})
          }
    })
})

//购物车按uid和商品名称搜索商品
server.get("/api/cart_Search_value",(req,res)=>{
    var uid=req.session.uid;
    if(!uid){
        res.send({code:-1,msg:"请登录",uname:"亲，请登录"});
        return;
    }
    var key=req.query.key;
    pool.query(`SELECT lid,pic,price,title FROM gwc_cart WHERE uid=${uid} and title like "%${key}%"`,(err,result)=>{
        if(err) throw err;
        if(result.length==0){
            res.send({code:-2,msg:"查询失败"})
        }else{
            res.send({code:1,msg:"查询成功",rows:result})
        }
    })
})

//列表按lid搜索查找商品对应信息
server.get('/api/load_lid',(req,res)=>{
    var lid=req.query.lid;
    pool.query("SELECT lid,pic,price,title FROM gwc_product WHERE lid=?",[lid],(err,result)=>{
        if(err) throw err;
        if(result.length==0){
            res.send({code:-1,msg:"查询失败"})
        }else{
            res.send({code:1,msg:"查询成功",rows:result})
        }
    })
})